## Some notes about the tests:
* case0: sanity case.
* case1: FIFO full case.

## How to run:
* run case0: make // Or make case0
* run case1: make case1

## How to start the verdi:
* make verdi

## How to clean:
* make clean
